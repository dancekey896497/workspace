# 教材取材与改编说明

检索与读取：2026-10-04。只选理解KS材料所需的小节。原文摘录保存在同目录excerpts.json，网页可直接查看。新增数字、中文译编和图示不声称是原作者原话或现场实测。

## Hugging Face Transformers：Caching

- 原作者：Hugging Face Team
- [原文入口](https://github.com/huggingface/transformers/blob/8cb5963cc22174954e7dca2c0a3320b7dc2f4edc/docs/source/en/cache_explanation.md)
- 定位：docs/source/en/cache_explanation.md
- 许可/引用方式：Apache-2.0
- 使用方式：直接摘录与中文译编：为什么缓存、逐层追加、形状与位置。例子中的数字和动画由本文补充。

## Hugging Face：Chat templates

- 原作者：Hugging Face Team
- [原文入口](https://github.com/huggingface/transformers/blob/8cb5963cc22174954e7dca2c0a3320b7dc2f4edc/docs/source/en/chat_templating.md)
- 定位：docs/source/en/chat_templating.md
- 许可/引用方式：Apache-2.0
- 使用方式：直接摘录消息列表与模板代码；中文解释角色标记如何改变真正的输入。

## 《动手学深度学习》2.1 数据操作

- 原作者：Aston Zhang、Zachary C. Lipton、李沐、Alexander J. Smola及贡献者
- [原文入口](https://github.com/d2l-ai/d2l-zh/blob/e6b18ccea71451a55fcd861d7b96fddf2587b09a/chapter_preliminaries/ndarray.md)
- 定位：chapter_preliminaries/ndarray.md
- 许可/引用方式：Apache-2.0
- 使用方式：直接使用张量定义、reshape示例；补出数组结果、逐元素寻址和KV形状对应。

## 《动手学深度学习》10.1 注意力提示

- 原作者：D2L作者及贡献者
- [原文入口](https://github.com/d2l-ai/d2l-zh/blob/e6b18ccea71451a55fcd861d7b96fddf2587b09a/chapter_attention-mechanisms/attention-cues.md)
- 定位：chapter_attention-mechanisms/attention-cues.md
- 许可/引用方式：Apache-2.0
- 使用方式：摘录查询、键、值与加权汇聚的解释；另做一个两行数字例子，不复制原书插图。

## 《动手学深度学习》12.2 异步计算

- 原作者：D2L作者及贡献者
- [原文入口](https://github.com/d2l-ai/d2l-zh/blob/e6b18ccea71451a55fcd861d7b96fddf2587b09a/chapter_computational-performance/async-computation.md)
- 定位：chapter_computational-performance/async-computation.md
- 许可/引用方式：Apache-2.0
- 使用方式：摘录同步等待示例与前后端解释；用CPU提交和后台完成两条时间线说明KS保存等待。

## Hugging Face Nanotron：ParallelContext / Pipeline parallelism

- 原作者：Hugging Face Nanotron贡献者
- [原文入口](https://github.com/huggingface/nanotron/blob/fb0747bac263a4c3a8ff4d724869a533afb561d8/docs/docs.md)
- 定位：docs/docs.md
- 许可/引用方式：Apache-2.0
- 使用方式：翻译进程分组和流水线的完整小例子。仅用前向计算解释分工，不引入训练、反向传播或梯度同步。

## vLLM：Automatic Prefix Caching

- 原作者：vLLM贡献者
- [原文入口](https://github.com/vllm-project/vllm/blob/bcf2be96120005e9aea171927f85055a6a5c0cf6/docs/features/automatic_prefix_caching.md)
- 定位：docs/features/automatic_prefix_caching.md
- 许可/引用方式：Apache-2.0
- 使用方式：直接译编长文档问答例子与prefill/decode收益范围。

## vLLM：前缀缓存的块与哈希

- 原作者：vLLM贡献者
- [原文入口](https://github.com/vllm-project/vllm/blob/bcf2be96120005e9aea171927f85055a6a5c0cf6/docs/design/prefix_caching.md)
- 定位：docs/design/prefix_caching.md
- 许可/引用方式：Apache-2.0
- 使用方式：保留官方三块文本示例，解释为什么缓存键还包含前面的上下文。

## 《从零构建大语言模型》配套：KV Cache代码

- 原作者：Sebastian Raschka
- [原文入口](https://github.com/rasbt/LLMs-from-scratch/blob/cdbd33e6d57a71e20ea31434841095fac50cecd8/ch04/03_kv-cache/gpt_with_kv_cache.py)
- 定位：ch04/03_kv-cache/gpt_with_kv_cache.py
- 许可/引用方式：项目代码许可证；Apache-2.0文本附书籍/图片排除条款，见随包原许可证
- 使用方式：仅摘录开源配套代码并逐行解释；不转载商业书页或该仓库排除授权的相关图片。

## LMCache: An Efficient KV Cache Layer for Enterprise-Scale LLM Inference

- 原作者：Yuhan Liu 等，Tensormesh / University of Chicago
- [原文入口](https://lmcache.ai/tech_report.pdf#page=3)
- 定位：PDF 第3页 Figure 2；arXiv:2510.09665v2，2025-12-05
- 许可/引用方式：原论文权利归作者；本文只作简短概述与链接
- 使用方式：图2区分跨请求复用与P→D交接；HTML中的双路径图是本文重新绘制的示意，不是论文原图。

## Prometheus：Metric types

- 原作者：Prometheus Authors
- [原文入口](https://prometheus.io/docs/concepts/metric_types/)
- 定位：Counter / Gauge / Histogram；读取于2026-10-04
- 许可/引用方式：Apache-2.0；官方页面声明
- 使用方式：采用官方三类指标的含义；GET耗时与排队数字为本文独立构造的例子。

## PyTorch 2.9：Tensor.stride

- 原作者：PyTorch Contributors
- [原文入口](https://docs.pytorch.org/docs/2.9/generated/torch.Tensor.stride.html)
- 定位：Example；固定文档版本2.9
- 许可/引用方式：原文权利归项目；这里只链接并概述步长定义
- 使用方式：用官方定义核对“沿某维移动一步跨过多少元素”；图中数组为本文自制。

代码与摘录按各自许可使用；本文不复现商业书页或其排除授权的图片，不打包整本论文。
