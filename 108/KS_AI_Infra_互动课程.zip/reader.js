'use strict';
const $=(s,root=document)=>root.querySelector(s);
const $$=(s,root=document)=>[...root.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const chapters=COURSE.chapters;
const snippets=Object.fromEntries(COURSE.snippets.map(s=>[s.id,s]));
let current=chapters[0],animationTimer=null;
function stopAnimation(){clearInterval(animationTimer);animationTimer=null;}
function download(name,text){const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function modal(title,html){$('#source-title').textContent=title;$('#source-content').innerHTML=html;if(!$('#source-dialog').open)$('#source-dialog').showModal();}
function closeMenu(){$('#sidebar').classList.remove('open');$('#mobile-menu').setAttribute('aria-expanded','false');}
function navigate(id){closeMenu();if(location.hash==='#'+id)render();else location.hash=id;}
function termHTML(key){const t=COURSE.terms[key];return `<div class="term-entry"><div><b>${esc(t[0])}</b><span lang="en">${esc(t[1])}</span></div><p>${esc(t[2])}${t[3]?` <a href="${esc(t[3])}" target="_blank" rel="noopener">名称出处 ↗</a>`:''}</p></div>`;}
function showTerm(key){modal('名词对照',termHTML(key));}
function sidebar(){
 $('#sidebar').innerHTML=COURSE.parts.map((part,p)=>`<div class="nav-group">0${p+1} / ${part.name}<small>${part.note}</small></div>${chapters.filter(c=>c.part===part.id).map((c,i)=>`<button data-go="${c.id}" ${c.id===current.id?'class="active" aria-current="page"':''}><span class="num">${String(i+1).padStart(2,'0')}</span><span>${esc(c.title)}</span></button>`).join('')}`).join('')+`<div class="nav-foot"><button id="all-terms">中文 / English 名词对照</button><button id="material-list">原材料与代码出处</button><p>仅围绕 KS 文件中的知识<br>概念与图示离线可读</p></div>`;
 $$('[data-go]',$('#sidebar')).forEach(b=>b.onclick=()=>navigate(b.dataset.go));
 $('#all-terms').onclick=()=>showGlossary('');
 $('#material-list').onclick=()=>modal('材料与代码出处',`<p>原目录：<code>${esc(COURSE.sourceRoot)}</code>。15 个文件均已读取；Word 与 Markdown 格式副本按内容去重。较新报告的结论优先于早期方案。</p><div class="material-list">${COURSE.materials.map(m=>`<div>${esc(m.name)}<small>${Math.ceil(m.bytes/1024)} KB</small></div>`).join('')}</div><p class="note">材料记录了客户变慢反馈，尚未确认客户根因。远端代码使用固定提交；图中数字为逻辑示意。</p><p><a href="knowledge-coverage.md" target="_blank">知识覆盖说明</a> · <a href="THIRD_PARTY_NOTICES.md" target="_blank">代码归属与许可证</a></p><div class="attachment-list">${['make_cases.py','README.md','run_manifest.csv','request_evidence.csv','stage_events.csv','comparison.csv'].map(f=>`<a href="attachments/${f}" download>原附件 · ${f}</a>`).join('')}</div>`);
}
function showGlossary(query){
 const keys=Object.keys(COURSE.terms).filter(k=>COURSE.terms[k].join(' ').toLowerCase().includes(query.toLowerCase()));
 modal('中文 / English 名词对照',`<input id="glossary-search" type="search" value="${esc(query)}" placeholder="输入中文、英文或缩写" aria-label="搜索名词"><div id="glossary-results">${keys.map(termHTML).join('')}</div>`);
 $('#glossary-search').oninput=e=>{$('#glossary-results').innerHTML=Object.keys(COURSE.terms).filter(k=>COURSE.terms[k].join(' ').toLowerCase().includes(e.target.value.toLowerCase())).map(termHTML).join('');};
}
function codeHTML(s){
 const original=s.code.split('\n');
 const indent=Math.min(...original.filter(line=>line.trim()).map(line=>line.length-line.trimStart().length));
 const rows=original.map((line,i)=>`<span class="code-line" data-line="${s.start+i}"><span class="line-number" aria-hidden="true">${s.start+i}</span><span class="line-code">${esc(line.slice(indent))||' '}</span></span>`).join('');
 return `<section class="source-code" id="code-${s.id}"><div class="snippet-kicker">${s.commit?'仓库原文 · '+s.language:'原附件 · '+s.language}</div><h3>${esc(s.title)}</h3><p>${esc(s.meaning)}</p><div class="source-meta"><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.repo)} ↗</a>${s.commit?`<span>固定提交 <code>${s.commit.slice(0,12)}</code></span>`:''}<span>L${s.start}–${s.end}</span></div><div class="source-path">${esc(s.path)}</div><div class="codebox source-box"><div class="codehead"><span>${s.language} · 原始行号</span><button class="small" data-copy="${s.id}">复制片段</button></div><pre tabindex="0" aria-label="${esc(s.title)}，可横向滚动"><code>${rows}</code></pre></div><div class="line-notes">${s.steps.map((step,i)=>`<button class="line-note" data-snippet="${s.id}" data-step="${i}" aria-pressed="false"><span>L${step.start}${step.end!==step.start?'–'+step.end:''}</span><span>${esc(step.text)}</span></button>`).join('')}</div><p class="code-connection">${esc(s.connection)}</p></section>`;
}
function bilingualBold(){
 const seen=new Set();
 $$('.prose b').forEach(b=>{
   const raw=b.textContent.trim(),base=raw.split(/[（(]/)[0].trim().toLowerCase();
   const key=current.terms.find(k=>{
     const t=COURSE.terms[k],aliases=[t[0],...t[1].split(/ · | \/ /)];
     return aliases.some(a=>a.toLowerCase()===base);
   });
   if(!key)return;
   const t=COURSE.terms[key];
   if(!seen.has(key)){b.textContent=`${t[0]}（${t[1].replace(' · ','，')}）`;seen.add(key);}
   b.classList.add('inline-term');b.title=t[2];b.tabIndex=0;b.setAttribute('role','button');b.setAttribute('aria-label',`${t[0]}：查看名词解释`);
   b.onclick=()=>showTerm(key);b.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();showTerm(key);}};
 });
}
function render(){
 stopAnimation();
 const id=location.hash.slice(1).split('/')[0];current=chapters.find(c=>c.id===id)||chapters[id==='advanced'?8:0];
 const part=COURSE.parts.find(p=>p.id===current.part),partIndex=current.part==='intro'?0:1;
 const index=chapters.indexOf(current),within=chapters.filter(c=>c.part===current.part).indexOf(current);
 document.title=`${current.title} · KS AI Infra`;
 sidebar();
 let content=current.sections.map(([title,body],i)=>`<section class="prose" id="section-${i}"><h2>${esc(title)}</h2><div class="prose-body">${body}</div></section>${i===(current.labAfter??1)?'<div id="lab-host"></div>':''}`).join('');
 $('#main').innerHTML=`<div class="part-tabs" aria-label="选择阅读部分">${COURSE.parts.map((p,i)=>`<button class="${p.id===part.id?'active':''}" data-part="${i?'b1':'a1'}" aria-current="${p.id===part.id?'true':'false'}"><span>0${i+1} / ${p.name}</span><small>${p.note}</small></button>`).join('')}</div>
 <header class="chapter-head"><div class="eyebrow">${part.en} / ${String(within+1).padStart(2,'0')}</div><h1>${esc(current.title)}</h1><p class="lead">${esc(current.summary)}</p>${within===0?`<p class="part-description">${esc(part.description)}${partIndex===0?' 正文顺读约 1 小时；连同图示与代码对照，约 2–3 小时。':''}</p>`:''}</header>
 ${content}<p class="note contrast">${esc(current.contrast)}</p>
 ${current.snippets.length?`<section id="source-excerpts"><h2>在真实代码中对照</h2><p class="muted">保留原始代码与行号。下方解释可点击，高亮对应行；仓库链接指向固定版本。</p>${current.snippets.map(id=>codeHTML(snippets[id])).join('')}</section>`:''}
 ${current.references?.length?`<section id="textbook-sources"><h2>本页用到的教材与文档</h2>${textbookSourcesHTML(current.references)}</section>`:''}
 <section id="chapter-terms"><h2>本节名词 · 中文 / English</h2><div class="term-grid">${current.terms.map(termHTML).join('')}</div></section>
 <section id="material-sources"><h2>对应原材料</h2><div class="source-links">${current.sources.map((s,i)=>`<button class="source-btn" data-source="${i}">${esc(s.name)}<span>${esc(s.marker||'正文')} · L${s.start}–${s.end}</span></button>`).join('')}</div></section>
 <footer class="footer-nav">${index?`<button data-go="${chapters[index-1].id}">← ${esc(chapters[index-1].title)}</button>`:'<span></span>'}${index<chapters.length-1?`<button data-go="${chapters[index+1].id}">${esc(chapters[index+1].title)} →</button>`:`<a href="#a1">返回快速扫盲 ↑</a>`}</footer>`;
 $('#rail').innerHTML=`<div class="eyebrow">本页</div>${current.sections.map(([t],i)=>`<a href="#${current.id}/section-${i}" data-anchor="section-${i}">${esc(t)}</a>`).join('')}<a href="#${current.id}/interactive" data-anchor="interactive">逻辑图示</a>${current.snippets.length?'<a href="#'+current.id+'/source-excerpts" data-anchor="source-excerpts">代码与逐行解释</a>':''}<a href="#${current.id}/chapter-terms" data-anchor="chapter-terms">中文 / English</a><a href="#${current.id}/material-sources" data-anchor="material-sources">对应原材料</a>`;
 $$('[data-anchor]',$('#rail')).forEach(a=>a.onclick=e=>{e.preventDefault();$('#'+a.dataset.anchor)?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});});
 $$('[data-part]',$('#main')).forEach(b=>b.onclick=()=>navigate(b.dataset.part));
 $$('[data-go]',$('#main')).forEach(b=>b.onclick=()=>navigate(b.dataset.go));
 $$('[data-source]').forEach(b=>b.onclick=()=>{const s=current.sources[Number(b.dataset.source)];modal(s.name,`<p class="muted">${esc(s.marker||'正文')} · 原文摘录 L${s.start}–${s.end}</p><pre>${esc(s.excerpt)}</pre>`);});
 $$('[data-step]').forEach(b=>b.onclick=()=>{
   const s=snippets[b.dataset.snippet],step=s.steps[Number(b.dataset.step)],scope=$('#code-'+s.id);
   $$('.line-note',scope).forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
   $$('.code-line',scope).forEach(line=>line.classList.toggle('highlight',Number(line.dataset.line)>=step.start&&Number(line.dataset.line)<=step.end));
 });
 $$('[data-copy]').forEach(b=>b.onclick=async()=>{const s=snippets[b.dataset.copy];try{await navigator.clipboard.writeText(s.code);b.textContent='已复制';}catch{download(s.id+(s.language==='C++'?'.h':'.py'),s.code);b.textContent='已下载片段';}});
 renderLab(current.lab,current.id);renderConcreteFigures();bindTextbookSources();bilingualBold();
 setupAnimation(current.lab);
 const anchor=location.hash.split('/')[1];
 if(anchor&&/^[a-z0-9-]+$/.test(anchor)&&$('#'+anchor))$('#'+anchor).scrollIntoView({behavior:'instant'});
 else window.scrollTo({top:0,behavior:'instant'});
 closeMenu();
}
function setupAnimation(type){
 if(type!=='request'&&type!=='async')return;
 const button=document.createElement('button');button.id='play-diagram';button.textContent='▶ 播放过程';button.setAttribute('aria-pressed','false');$('.controls',$('#lab-host')).prepend(button);
 button.onclick=()=>{
   if(animationTimer){stopAnimation();button.textContent=type==='request'?'▶ 继续播放':'↻ 重新播放';button.setAttribute('aria-pressed','false');return;}
   button.textContent='Ⅱ 暂停';button.setAttribute('aria-pressed','true');
   if(type==='request'){
     if($('.flow .lit',$('#lab-view'))?.textContent.startsWith('6.'))$('#request-reset').click();
     animationTimer=setInterval(()=>{
       $('#request-next').click();
       if($('.flow .lit',$('#lab-view'))?.textContent.startsWith('6.')){stopAnimation();button.textContent='↻ 再播一次';button.setAttribute('aria-pressed','false');}
     },1100);
   }else{
     let progress=0;const max=Math.max(n('a-compute'),n('a-put'));
     const view=$('#lab-view');$('#animation-clock')?.remove();
     const clock=document.createElement('div');clock.className='animation-clock';clock.id='animation-clock';view.append(clock);
     animationTimer=setInterval(()=>{
       progress=Math.min(max,progress+.5);
       if(!$('#animation-clock')){stopAnimation();button.textContent='▶ 播放过程';button.setAttribute('aria-pressed','false');return;}
       clock.textContent=`示意时间 ${progress.toFixed(1)} ms｜独立计算：${progress>=n('a-compute')?'完成':'执行中'}｜后台写入：${progress>=n('a-put')?'完成':'执行中'}｜${progress>=max?'两项完成，缓冲可重用':'依赖未齐，暂不能重用'}`;
       $$('.bar',view).forEach((bar,i)=>{if(i<2)bar.style.width=Math.min(progress,i===0?n('a-compute'):n('a-put'))/(n('a-compute')+n('a-put'))*100+'%';});
       if(progress>=max){stopAnimation();button.textContent='↻ 再播一次';button.setAttribute('aria-pressed','false');}
     },100);
   }
 };
}
function search(){
 const query=$('#search').value.trim().toLowerCase();if(!query)return;
 const matches=chapters.filter(c=>JSON.stringify(c).toLowerCase().includes(query)||c.terms.some(k=>COURSE.terms[k].join(' ').toLowerCase().includes(query))||c.snippets.some(k=>JSON.stringify(snippets[k]).toLowerCase().includes(query)));
 modal('查找结果',`<p>“${esc(query)}” · ${matches.length} 个相关主题</p><div class="result-list">${matches.map(c=>`<button data-result="${c.id}"><small>${c.part==='intro'?'快速扫盲':'进阶代码解析'}</small><strong>${esc(c.title)}</strong><span>${esc(c.summary)}</span></button>`).join('')||'<p>没有匹配结果，可试用缩写或中文名称。</p>'}</div>`);
 $$('[data-result]').forEach(b=>b.onclick=()=>{$('#source-dialog').close();navigate(b.dataset.result);});
}
$('#search').onkeydown=e=>{if(e.key==='Enter')search();};
$('#search').onsearch=()=>{if($('#search').value)search();};
$('#close-source').onclick=()=>$('#source-dialog').close();
$('#source-dialog').addEventListener('click',e=>{if(e.target===e.currentTarget){const r=e.currentTarget.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.currentTarget.close();}});
$('#mobile-menu').onclick=()=>{$('#sidebar').classList.toggle('open');$('#mobile-menu').setAttribute('aria-expanded',String($('#sidebar').classList.contains('open')));};
$('#theme').onclick=()=>{document.body.classList.toggle('dark');};
window.addEventListener('hashchange',render);
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopAnimation();const b=$('#play-diagram');if(b){b.textContent='▶ 播放过程';b.setAttribute('aria-pressed','false');}}});
render();
