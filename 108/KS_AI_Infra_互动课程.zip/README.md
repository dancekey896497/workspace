# KS AI Infra：快速扫盲与进阶代码解析

双击 index.html 或 打开课程.cmd，离线直接阅读。移动时请保留整个目录。

仅分两部分：快速扫盲（约1–3小时）与进阶代码解析。共16个主题，按概念依赖顺序组织；没有答题、解锁、自评、Gate或学习记录。页面交互用于请求动画、并行拓扑、缓存边界、地址偏移、异步重叠、参数对比与代码行高亮。

正文来源是 E:\work\ks\output 中15个文件。Word/Markdown格式副本去重；原报告最终结论优先于早期方案。主要概念同时给出中文、英文名称与缩写。仅补充理解材料所需的基础，不扩展成通用AI Infra百科。

本版引入12份教材章节、官方文档或论文条目：Hugging Face缓存与聊天模板、D2L数据操作/注意力/异步计算、Nanotron并行、vLLM前缀缓存、Raschka的KV缓存配套代码、LMCache技术报告、Prometheus指标与PyTorch步长说明。正文明确区分原文节选、中文译编和新增数字例子。教材原文摘录及出处在 reference-library/excerpts.json；论文只保留短概述与原PDF链接。

共28段代码片段，含6段新增教材代码、21段原有生产仓库代码与1段用户附件原文。每段给出仓库、固定commit、文件、行号、上下文与解释；点击解释可以高亮对应原始行。原生产片段在source-snapshots/excerpts.json，新教材片段在reference-library/excerpts.json。局部片段不能孤立运行，也不代表客户使用相同版本。作者归属和许可证见THIRD_PARTY_NOTICES.md；Raschka代码的原许可证附书籍和相关图片排除条款，因此没有转载该书图片或书页。

图示是浏览器中的逻辑模型，不连接模型服务。原附件保留在 attachments/。页面没有对客户NPU环境做运行或性能验证，不改变工作区已有学习进度。

工作区维护（压缩包只含阅读成品）：python -X utf8 build_course.py。本版具体例子和教材译编位于concrete_content.py；原知识与代码在reader_content.py与course_data.py；页面由reader.js、diagrams.js、foundations.js和style.css组成。构建只更新本目录文件。
