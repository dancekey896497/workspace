// Small data walkthroughs supplement the licensed textbook excerpts.
function renderConcreteFigures(){
 $$('[data-figure]').forEach(host=>{
  const type=host.dataset.figure;
  if(type==='cache-rows'){
   let step=0;
   const states=[
    {name:'预填充 Prefill',input:['我','喜欢'],old:[],fresh:['我','喜欢'],prediction:'苹果'},
    {name:'第一次解码 Decode 1',input:['苹果'],old:['我','喜欢'],fresh:['苹果'],prediction:'。'},
    {name:'第二次解码 Decode 2',input:['。'],old:['我','喜欢','苹果'],fresh:['。'],prediction:'EOS（结束）'},
   ];
   const draw=()=>{const s=states[step];host.innerHTML=`<div class="figure-heading">这一次，哪些数据已经有了？</div><div class="figure-tabs">${states.map((x,i)=>`<button data-cache-step="${i}" aria-pressed="${i===step}">${x.name}</button>`).join('')}</div><div class="cache-walk"><div><small>本次计算的输入</small><b>${s.input.join(' / ')}</b></div><span class="walk-arrow">→</span><div><small>本层缓存，旧的保留＋新的追加</small><div class="cache-chips">${s.old.map(w=>`<span class="cached">${w}<small>已缓存 K/V</small></span>`).join('')}${s.fresh.map(w=>`<span class="new-kv">${w}<small>本次新算 K/V</small></span>`).join('')}</div></div><span class="walk-arrow">→</span><div><small>本次预测出的下一个token</small><b>${s.prediction}</b></div></div><p class="figure-caption">${step===0?'先批量处理输入的两个token，产生第一个输出“苹果”。':'历史K/V仍参与注意力，但无须重新为旧位置生成同样的K/V。'} 右侧刚预测出的token，要在后续送入计算时才形成自己的KV；图只展开一个模型层。</p>`;
    $$('[data-cache-step]',host).forEach(b=>b.onclick=()=>{step=Number(b.dataset.cacheStep);draw();});
   };draw();
  }
  if(type==='attention-numbers'){
   let q=[1,0];
   const draw=()=>{const score=[q[0]*2,q[1]*2],sum=Math.exp(score[0])+Math.exp(score[1]),w=score.map(s=>Math.exp(s)/sum),out=[10*w[0],20*w[1]];
    host.innerHTML=`<div class="figure-heading">用两个历史位置，算一次注意力汇聚</div><div class="figure-tabs"><button data-query="x" aria-pressed="${q[0]===1}">Q = [1, 0]</button><button data-query="y" aria-pressed="${q[1]===1}">Q = [0, 1]</button></div><div class="table-wrap"><table><thead><tr><th>历史位置</th><th>键 K</th><th>值 V</th><th>Q·K分数</th><th>Softmax权重</th></tr></thead><tbody>${[[2,0],[0,2]].map((k,i)=>`<tr><td>${i+1}</td><td>[${k.join(', ')}]</td><td>${i===0?'[10, 0]':'[0, 20]'}</td><td>${score[i]}</td><td>${w[i].toFixed(3)}</td></tr>`).join('')}</tbody></table></div><div class="number-result">混合结果 = ${w[0].toFixed(3)} × [10, 0] + ${w[1].toFixed(3)} × [0, 20]<br><strong>≈ [${out[0].toFixed(2)}, ${out[1].toFixed(2)}]</strong></div><p class="figure-caption">Softmax(sᵢ)=exp(sᵢ)/Σexp(sⱼ)。切换Q时，历史K和V没有变，匹配权重与取出的混合结果会变。数值人为设置；为突出加权过程，此例省去标准注意力的缩放和掩码。</p>`;
    $$('[data-query]',host).forEach(b=>b.onclick=()=>{q=b.dataset.query==='x'?[1,0]:[0,1];draw();});
   };draw();
  }
  if(type==='prefix-records'){
   let mode=0;
   const old=[11,12,13,14,15,16,17,18],cases=[[11,12,13,14,15,16,27,28],[11,12,93,14,15,16,27,28],[99,12,13,14,15,16,17,18]],labels=['只换最后的问题','第3个token改了','开头插入不同身份'];
   const draw=()=>{const row=cases[mode];let common=0;while(common<old.length&&old[common]===row[common])common++;const blocks=Math.floor(common/4);host.innerHTML=`<div class="figure-heading">缓存按连续前缀匹配，不能跳过中间差异</div><div class="figure-tabs">${labels.map((x,i)=>`<button data-prefix-case="${i}" aria-pressed="${mode===i}">${x}</button>`).join('')}</div><div class="prefix-line"><b>旧请求</b>${old.map((v,i)=>`<span class="${i<blocks*4?'cached':''}">${v}</span>`).join('')}</div><div class="prefix-line"><b>新请求</b>${row.map((v,i)=>`<span class="${i<blocks*4?'cached':i<common?'tail-match':''}">${v}</span>`).join('')}</div><div class="number-result">从开头连续相同：<strong>${common}</strong> 个token；每块4个 → 完整候选块 <strong>${blocks}</strong> 个。</div><p class="figure-caption">绿色：完整前缀块；金色：相同但尚不足一块的尾部。后面的编号即使又相同，也不能绕过前面的分歧，直接当作相同计算上下文。</p>`;$$('[data-prefix-case]',host).forEach(b=>b.onclick=()=>{mode=Number(b.dataset.prefixCase);draw();});};draw();
  }
  if(type==='pipeline-ticks'){
   let tick=1;
   const draw=()=>{host.innerHTML=`<div class="figure-heading">两个阶段，同时处理不同的小批次</div><div class="figure-tabs">${[1,2,3].map(i=>`<button data-pipeline-tick="${i}" aria-pressed="${i===tick}">时段 ${i}：${(i-1)*10}–${i*10} ms</button>`).join('')}</div><div class="table-wrap"><table class="pipeline-grid"><thead><tr><th>设备职责</th><th>0–10ms</th><th>10–20ms</th><th>20–30ms</th></tr></thead><tbody>${[['阶段0：前半层',['A','B','空闲']],['阶段1：后半层',['空闲','A','B']]].map(([label,row])=>`<tr><th>${label}</th>${row.map((v,i)=>`<td class="${i+1===tick?'current-tick':''} ${v==='空闲'?'bubble-cell':'work-cell'}">${v}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="number-result">${['开始：阶段1尚未收到A的前半层结果。','重叠：阶段0处理B，阶段1处理A；同一批A仍按阶段顺序执行。','收尾：阶段1处理B；阶段0没有下一批，所以出现空闲。'][tick-1]}</div><p class="figure-caption">每阶段假设10ms、忽略通信。A在20ms完成，B在30ms完成。灰格是气泡。依据Nanotron文档中的batch 0 / batch 1过程重画，仅展示前向计算。</p>`;$$('[data-pipeline-tick]',host).forEach(b=>b.onclick=()=>{tick=Number(b.dataset.pipelineTick);draw();});};draw();
  }
  if(type==='pool-trip'){
   let state=0;const labels=['P1计算手册','共享写入完成','P2读取并采用'];
   const draw=()=>{host.innerHTML=`<div class="figure-heading">以后再用，与本次接着写，是两条用途</div><div class="figure-tabs">${labels.map((x,i)=>`<button data-pool-state="${i}" aria-pressed="${state===i}">${x}</button>`).join('')}</div><div class="trip-caption">请求A：手册＋问题A</div><div class="trip-row"><div class="trip-node ready">P1<small>计算手册KV</small></div><span>→ 本次KV交接 →</span><div class="trip-node">D<small>继续生成A的答案</small></div></div><div class="pool-link">跨请求保留：写入并发布 ↓</div><div class="pool-node ${state>=1?'ready':''}">共享池 / Shared Store<small>${state>=1?'手册KV已保存并可用':'尚未完成发布，P2不能据此确认可复用'}</small></div><div class="pool-link">后续请求：读取并采用 ↓</div><div class="trip-caption">稍后的请求B：同一手册＋问题B</div><div class="trip-row"><div class="trip-node ${state>=2?'ready':''}">P2<small>${state>=2?'从池读入，采用并少算':'本地没有手册KV'}</small></div><span>→ 本次KV交接 →</span><div class="trip-node">D<small>继续生成B的答案</small></div></div><p class="figure-caption">共享池连起不同请求A与B；横向P→D各自完成一条请求。图画的是数据用途，具体由P还是D回写共享池，取决于连接器实现与配置。</p>`;$$('[data-pool-state]',host).forEach(b=>b.onclick=()=>{state=Number(b.dataset.poolState);draw();});};draw();
  }
  if(type==='array-address'){
   let selected=6,bytes=2;
   const draw=()=>{const row=Math.floor(selected/4),col=selected%4;host.innerHTML=`<div class="figure-heading">点一个元素，看下标怎样变成字节偏移</div><div class="array-grid">${Array.from({length:12},(_,i)=>`<button data-array-index="${i}" aria-label="第${Math.floor(i/4)}行第${i%4}列，值${i}" aria-pressed="${selected===i}">${i}<small>[${Math.floor(i/4)},${i%4}]</small></button>`).join('')}</div><label class="dtype-control">每元素字节数 <select id="array-bytes"><option value="2" ${bytes===2?'selected':''}>2字节（例：float16）</option><option value="4" ${bytes===4?'selected':''}>4字节（例：float32）</option></select></label><div class="number-result">X[${row}, ${col}] = <strong>${selected}</strong><br>元素偏移 = ${row} × 4 + ${col} = ${selected}<br>字节偏移 = ${selected} × ${bytes} = <strong>${selected*bytes} 字节</strong></div><p class="figure-caption">按行连续存储、从基地址算起。示意选择dtype后改变的是每元素字节数；不是声称torch.arange默认就是float16。</p>`;$$('[data-array-index]',host).forEach(b=>b.onclick=()=>{selected=Number(b.dataset.arrayIndex);draw();});$('#array-bytes',host).onchange=e=>{bytes=Number(e.target.value);draw();};};draw();
  }
 });
}

function textbookSourcesHTML(ids){
 return (ids||[]).map(id=>{const r=COURSE.library.find(x=>x.id===id);return `<div class="reading-reference"><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.title)} ↗</a><p>${esc(r.usage)}</p><small>${esc(r.author)} · ${esc(r.license)}${r.commit?' · '+r.commit.slice(0,12):''}</small>${r.selections.length?`<button class="small" data-book="${r.id}">查看本页采用的原文</button>`:''}</div>`;}).join('');
}
function bindTextbookSources(){
 $$('[data-book]').forEach(b=>b.onclick=()=>{const r=COURSE.library.find(x=>x.id===b.dataset.book);modal(r.title,`<p>${esc(r.usage)}</p><p><a href="${esc(r.url)}" target="_blank" rel="noopener">打开原教材 ↗</a></p><p class="muted">${esc(r.path)} · ${esc(r.license)}</p>${r.selections.map(s=>`<h3>${s.start?'原文件 L'+s.start+'–'+s.end:'短引文'}</h3><pre>${esc(s.text)}</pre>`).join('')}`);});
}
